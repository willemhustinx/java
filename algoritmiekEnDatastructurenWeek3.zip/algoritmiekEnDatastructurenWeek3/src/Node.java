public class Node {
	private Node parent;

	public Node(Node ouder) {
		this.parent = ouder;
	}

	public void setParent(Node node) {
		this.parent = node;
		
	}
	
	public String toString()
	{
		return "";
	}
	

}
